
#pragma once

#include "buffer.h"

#ifndef LAB4_PRODUCER_H
#define LAB4_PRODUCER_H

void createProducer();
void removeProducer();
void createMessage(msg_t* msg);

#endif //LAB4_PRODUCER_H
