
#pragma once

#include "buffer.h"

#ifndef LAB4_CONSUMER_H
#define LAB4_CONSUMER_H

void createConsumer();
void removeConsumer();
void validateHash(msg_t* msg);

#endif //LAB4_CONSUMER_H
