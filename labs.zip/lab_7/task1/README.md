# LAB7 / TASK1

## Conditional variables and threads

## Instructions

1. At first go to folder
```
cd /path/to/lab7/task1
```
2. Build project with commands
```
make clean
make
```
3. Run it
```
./msg
```
